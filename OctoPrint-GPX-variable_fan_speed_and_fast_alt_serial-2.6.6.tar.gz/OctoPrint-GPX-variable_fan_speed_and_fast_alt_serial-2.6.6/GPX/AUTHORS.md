# Authors

GPX was originally written by Dr. Henry Thomas (aka Wingcommander) in April 2013

The following people have subsequently contributed to GPX's code base:

* [DNewman](https://github.com/dcnewman)
* [Mark Walker](https://github.com/markwal)
* [Chow Loong Jin](https://github.com/hyperair)
